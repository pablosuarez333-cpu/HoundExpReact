import {
  screen,
} from "@testing-library/react";

import userEvent from "@testing-library/user-event";

import RegisterForm from "../src/components/RegisterForm";

import {
  renderWithStore,
} from "./testUtils";

describe("RegisterForm", () => {
  test("debe registrar una nueva guía correctamente", async () => {
    const user =
      userEvent.setup();

    const { store } =
      renderWithStore(
        <RegisterForm />
      );

    await user.type(
      screen.getByLabelText(
        /número de guía/i
      ),
      "HE987654"
    );

    await user.type(
      screen.getByLabelText(
        /destinatario/i
      ),
      "María López"
    );

    await user.type(
      screen.getByLabelText(
        /origen/i
      ),
      "Toluca"
    );

    await user.type(
      screen.getByLabelText(
        /destino/i
      ),
      "Monterrey"
    );

    await user.click(
      screen.getByRole(
        "button",
        {
          name: /registrar guía/i,
        }
      )
    );

    const state =
      store.getState();

    expect(
      state.guides.guides
    ).toHaveLength(1);

    expect(
      state.guides.guides[0]
        .guideNumber
    ).toBe("HE987654");

    expect(
      state.guides.guides[0]
        .recipient
    ).toBe("María López");

    expect(
      state.guides.guides[0]
        .origin
    ).toBe("Toluca");

    expect(
      state.guides.guides[0]
        .destination
    ).toBe("Monterrey");

    expect(
      state.guides.guides[0]
        .status
    ).toBe("Pendiente");

    expect(
      state.guides.history
    ).toHaveLength(1);

    expect(
      state.guides.history[0]
        .action
    ).toBe("Guía registrada");
  });

  test("debe mostrar error cuando faltan campos obligatorios", async () => {
    const user =
      userEvent.setup();

    const { store } =
      renderWithStore(
        <RegisterForm />
      );

    await user.click(
      screen.getByRole(
        "button",
        {
          name: /registrar guía/i,
        }
      )
    );

    expect(
      screen.getByText(
        /todos los campos son obligatorios/i
      )
    ).toBeInTheDocument();

    expect(
      store.getState().guides.guides
    ).toHaveLength(0);
  });

  test("debe limpiar los campos después de registrar", async () => {
    const user =
      userEvent.setup();

    renderWithStore(
      <RegisterForm />
    );

    const guideInput =
      screen.getByLabelText(
        /número de guía/i
      );

    const recipientInput =
      screen.getByLabelText(
        /destinatario/i
      );

    const originInput =
      screen.getByLabelText(
        /origen/i
      );

    const destinationInput =
      screen.getByLabelText(
        /destino/i
      );

    await user.type(
      guideInput,
      "HE123"
    );

    await user.type(
      recipientInput,
      "Ana"
    );

    await user.type(
      originInput,
      "Toluca"
    );

    await user.type(
      destinationInput,
      "Puebla"
    );

    await user.click(
      screen.getByRole(
        "button",
        {
          name: /registrar guía/i,
        }
      )
    );

    expect(guideInput).toHaveValue("");
    expect(recipientInput).toHaveValue("");
    expect(originInput).toHaveValue("");
    expect(destinationInput).toHaveValue("");
  });
});