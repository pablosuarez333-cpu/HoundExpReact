import {
  screen,
} from "@testing-library/react";

import userEvent from "@testing-library/user-event";

import GuideList from "../src/components/GuideList";

import {
  addGuide,
} from "../src/store/guideSlice";

import type {
  Guide,
} from "../src/interfaces/Guide";

import {
  act,
  screen,
} from "@testing-library/react";

import {
  renderWithStore,
} from "./testUtils";

const guide: Guide = {
  id: "guide-test-1",
  guideNumber: "HE100001",
  recipient: "Carlos Ruiz",
  origin: "Toluca",
  destination: "Guadalajara",
  status: "Pendiente",
  date: "07/09/2026",
};

describe("GuideList", () => {
  test("debe mostrar las guías registradas", () => {
    const { store } =
      renderWithStore(
        <GuideList />
      );

    store.dispatch(
      addGuide(guide)
    );

    expect(
      screen.getByText(
        "HE100001"
      )
    ).toBeInTheDocument();

    expect(
      screen.getByText(
        "Carlos Ruiz"
      )
    ).toBeInTheDocument();
  });

  test("debe actualizar una guía siguiendo Pendiente → En tránsito → Entregada", async () => {
    const user =
      userEvent.setup();

    const { store } =
      renderWithStore(
        <GuideList />
      );

    store.dispatch(
      addGuide(guide)
    );

    const statusSelect =
      screen.getByRole(
        "combobox",
        {
          name: /estado de la guía HE100001/i,
        }
      );

    expect(statusSelect).toHaveValue(
      "Pendiente"
    );

    await user.selectOptions(
      statusSelect,
      "En tránsito"
    );

    expect(
      store.getState()
        .guides.guides[0]
        .status
    ).toBe("En tránsito");

    expect(statusSelect).toHaveValue(
      "En tránsito"
    );

    await user.selectOptions(
      statusSelect,
      "Entregada"
    );

    expect(
      store.getState()
        .guides.guides[0]
        .status
    ).toBe("Entregada");

    expect(statusSelect).toHaveValue(
      "Entregada"
    );
  });

  test("la opción Entregada debe estar deshabilitada mientras la guía está Pendiente", () => {
    const { store } =
      renderWithStore(
        <GuideList />
      );

    store.dispatch(
      addGuide(guide)
    );

    const deliveredOption =
      screen.getByRole(
        "option",
        {
          name: "Entregada",
        }
      );

    expect(
      deliveredOption
    ).toBeDisabled();
  });

  test("debe permitir cancelar una guía pendiente", async () => {
    const user =
      userEvent.setup();

    const { store } =
      renderWithStore(
        <GuideList />
      );

    store.dispatch(
      addGuide(guide)
    );

    const statusSelect =
      screen.getByRole(
        "combobox",
        {
          name: /estado de la guía HE100001/i,
        }
      );

    await user.selectOptions(
      statusSelect,
      "Cancelada"
    );

    expect(
      store.getState()
        .guides.guides[0]
        .status
    ).toBe("Cancelada");
  });
});