import reducer, {
  addGuide,
  clearGuides,
  clearHistory,
  removeGuide,
  updateGuideStatus,
} from "../src/store/guideSlice";

import type {
  Guide,
} from "../src/interfaces/Guide";

const createGuide = (
  overrides: Partial<Guide> = {}
): Guide => {
  return {
    id: "guide-1",
    guideNumber: "HE123456",
    recipient: "Juan Pérez",
    origin: "Toluca",
    destination: "Ciudad de México",
    status: "Pendiente",
    date: "07/09/2026",
    ...overrides,
  };
};

describe("guideSlice", () => {
  test("debe retornar el estado inicial", () => {
    const state = reducer(
      undefined,
      {
        type: "unknown",
      }
    );

    expect(state.guides).toEqual([]);
    expect(state.history).toEqual([]);
  });

  test("addGuide debe añadir una guía", () => {
    const guide = createGuide();

    const state = reducer(
      undefined,
      addGuide(guide)
    );

    expect(state.guides).toHaveLength(1);

    expect(state.guides[0]).toEqual(
      guide
    );

    expect(state.history).toHaveLength(
      1
    );

    expect(
      state.history[0].action
    ).toBe("Guía registrada");

    expect(
      state.history[0].guideId
    ).toBe(guide.id);
  });

  test("addGuide no debe permitir números de guía duplicados", () => {
    const firstGuide = createGuide();

    const duplicateGuide = createGuide({
      id: "guide-2",
      guideNumber: "he123456",
    });

    let state = reducer(
      undefined,
      addGuide(firstGuide)
    );

    state = reducer(
      state,
      addGuide(duplicateGuide)
    );

    expect(state.guides).toHaveLength(1);
    expect(state.history).toHaveLength(
      1
    );
  });

  test("debe actualizar de Pendiente a En tránsito", () => {
    const guide = createGuide();

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      updateGuideStatus({
        id: guide.id,
        status: "En tránsito",
      })
    );

    expect(
      state.guides[0].status
    ).toBe("En tránsito");

    expect(
      state.history.at(-1)?.action
    ).toBe(
      "Estado cambiado de Pendiente a En tránsito"
    );
  });

  test("debe actualizar de En tránsito a Entregada", () => {
    const guide = createGuide({
      status: "En tránsito",
    });

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      updateGuideStatus({
        id: guide.id,
        status: "Entregada",
      })
    );

    expect(
      state.guides[0].status
    ).toBe("Entregada");
  });

  test("no debe permitir saltar directamente de Pendiente a Entregada", () => {
    const guide = createGuide();

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    const historyLength =
      state.history.length;

    state = reducer(
      state,
      updateGuideStatus({
        id: guide.id,
        status: "Entregada",
      })
    );

    expect(
      state.guides[0].status
    ).toBe("Pendiente");

    expect(state.history).toHaveLength(
      historyLength
    );
  });

  test("no debe permitir regresar de En tránsito a Pendiente", () => {
    const guide = createGuide({
      status: "En tránsito",
    });

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      updateGuideStatus({
        id: guide.id,
        status: "Pendiente",
      })
    );

    expect(
      state.guides[0].status
    ).toBe("En tránsito");
  });

  test("debe permitir cancelar una guía pendiente", () => {
    const guide = createGuide();

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      updateGuideStatus({
        id: guide.id,
        status: "Cancelada",
      })
    );

    expect(
      state.guides[0].status
    ).toBe("Cancelada");
  });

  test("una guía entregada no debe volver a cambiar de estado", () => {
    const guide = createGuide({
      status: "Entregada",
    });

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      updateGuideStatus({
        id: guide.id,
        status: "Cancelada",
      })
    );

    expect(
      state.guides[0].status
    ).toBe("Entregada");
  });

  test("removeGuide debe eliminar una guía", () => {
    const guide = createGuide();

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      removeGuide(guide.id)
    );

    expect(state.guides).toHaveLength(0);

    expect(
      state.history.at(-1)?.action
    ).toBe("Guía eliminada");
  });

  test("clearHistory debe eliminar únicamente el historial", () => {
    const guide = createGuide();

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      clearHistory()
    );

    expect(state.guides).toHaveLength(1);
    expect(state.history).toHaveLength(
      0
    );
  });

  test("clearGuides debe eliminar guías e historial", () => {
    const guide = createGuide();

    let state = reducer(
      undefined,
      addGuide(guide)
    );

    state = reducer(
      state,
      clearGuides()
    );

    expect(state.guides).toEqual([]);
    expect(state.history).toEqual([]);
  });
});